"""
schema_validator.py
-------------------
Enforces schema contracts on incoming data streams.
Flags rows with missing required fields, unexpected nulls,
and out-of-range sensor values. Separates clean vs. quarantined records.
"""

import logging
from pyspark.sql import DataFrame
from pyspark.sql import functions as F

logger = logging.getLogger(__name__)

# Per-source validation rules: {column: (min, max)} for numeric range checks
RANGE_RULES = {
    "telemetry": {
        "engine_temp_c": (-50, 1200),
        "vibration_hz": (0, 500),
        "fuel_flow_kg_hr": (0, 20000),
        "altitude_ft": (-1000, 60000),
        "airspeed_kts": (0, 700),
    },
    "flight_records": {
        "delay_minutes": (-60, 1440),
    },
}

REQUIRED_FIELDS = {
    "telemetry": ["flight_id", "tail_number", "event_ts"],
    "flight_records": ["flight_id", "tail_number", "scheduled_dep"],
    "maintenance_logs": ["tail_number", "component_id", "event_ts"],
}


class SchemaValidator:
    """
    Applies schema enforcement rules to a DataFrame for a named source.
    Adds a `_validation_passed` boolean column and logs quarantine counts.
    """

    def enforce(self, df: DataFrame, source: str) -> DataFrame:
        df = self._check_required_fields(df, source)
        df = self._check_ranges(df, source)
        self._log_quarantine_rate(df, source)
        # Return only clean records; quarantine path would write failures elsewhere
        return df.filter(F.col("_validation_passed")).drop("_validation_passed")

    def _check_required_fields(self, df: DataFrame, source: str) -> DataFrame:
        required = REQUIRED_FIELDS.get(source, [])
        condition = F.lit(True)
        for col in required:
            condition = condition & F.col(col).isNotNull()
        return df.withColumn("_validation_passed", condition)

    def _check_ranges(self, df: DataFrame, source: str) -> DataFrame:
        rules = RANGE_RULES.get(source, {})
        for col, (lo, hi) in rules.items():
            if col in df.columns:
                in_range = (
                    F.col(col).isNull() |
                    ((F.col(col) >= lo) & (F.col(col) <= hi))
                )
                df = df.withColumn(
                    "_validation_passed",
                    F.col("_validation_passed") & in_range
                )
        return df

    def _log_quarantine_rate(self, df: DataFrame, source: str):
        total = df.count()
        failed = df.filter(~F.col("_validation_passed")).count()
        rate = failed / total if total > 0 else 0
        logger.info(f"[{source}] Validation: {total} total, {failed} quarantined ({rate:.1%})")
        if rate > 0.05:
            logger.warning(f"[{source}] Quarantine rate exceeds 5% threshold — investigate upstream.")
