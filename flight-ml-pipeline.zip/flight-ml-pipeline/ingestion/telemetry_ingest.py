"""
telemetry_ingest.py
-------------------
PySpark batch ingestion job for aircraft telemetry, flight records,
and maintenance logs. Reads raw data from S3, applies schema validation,
handles late-arriving records, and writes clean feature-ready tables.
"""

import argparse
import logging
from datetime import datetime, timedelta

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType,
    TimestampType, IntegerType, BooleanType
)

from schema_validator import SchemaValidator
from late_arrival_handler import LateArrivalHandler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema definitions
# ---------------------------------------------------------------------------

TELEMETRY_SCHEMA = StructType([
    StructField("flight_id", StringType(), False),
    StructField("tail_number", StringType(), False),
    StructField("event_ts", TimestampType(), False),
    StructField("engine_temp_c", DoubleType(), True),
    StructField("vibration_hz", DoubleType(), True),
    StructField("fuel_flow_kg_hr", DoubleType(), True),
    StructField("altitude_ft", DoubleType(), True),
    StructField("airspeed_kts", DoubleType(), True),
    StructField("source_system", StringType(), True),   # fleet-gen tag
])

FLIGHT_RECORD_SCHEMA = StructType([
    StructField("flight_id", StringType(), False),
    StructField("origin", StringType(), False),
    StructField("destination", StringType(), False),
    StructField("scheduled_dep", TimestampType(), False),
    StructField("actual_dep", TimestampType(), True),
    StructField("delay_minutes", IntegerType(), True),
    StructField("delay_category", StringType(), True),
    StructField("aircraft_type", StringType(), True),
    StructField("tail_number", StringType(), False),
])

MAINTENANCE_LOG_SCHEMA = StructType([
    StructField("tail_number", StringType(), False),
    StructField("component_id", StringType(), False),
    StructField("event_type", StringType(), False),    # inspection / repair / replacement
    StructField("event_ts", TimestampType(), False),
    StructField("technician_id", StringType(), True),
    StructField("notes", StringType(), True),
])


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------

class TelemetryIngestionJob:
    """
    Orchestrates reading, validating, and writing all three raw data sources.
    """

    def __init__(self, spark: SparkSession, date: str, s3_bucket: str, output_path: str):
        self.spark = spark
        self.date = date
        self.s3_bucket = s3_bucket
        self.output_path = output_path
        self.validator = SchemaValidator()
        self.late_handler = LateArrivalHandler(lookback_days=3)

    def _s3_path(self, prefix: str) -> str:
        return f"s3://{self.s3_bucket}/{prefix}/date={self.date}/"

    def read_telemetry(self):
        logger.info(f"Reading telemetry for {self.date}")
        df = self.spark.read.schema(TELEMETRY_SCHEMA).parquet(
            self._s3_path("raw/telemetry")
        )
        df = self.validator.enforce(df, "telemetry")
        df = self.late_handler.detect_and_flag(df, ts_col="event_ts")
        return df

    def read_flight_records(self):
        logger.info(f"Reading flight records for {self.date}")
        df = self.spark.read.schema(FLIGHT_RECORD_SCHEMA).parquet(
            self._s3_path("raw/flights")
        )
        df = self.validator.enforce(df, "flight_records")
        return df

    def read_maintenance_logs(self):
        logger.info(f"Reading maintenance logs for {self.date}")
        df = self.spark.read.schema(MAINTENANCE_LOG_SCHEMA).parquet(
            self._s3_path("raw/maintenance")
        )
        df = self.validator.enforce(df, "maintenance_logs")
        return df

    def write(self, df, name: str):
        path = f"{self.output_path}/{name}/date={self.date}"
        logger.info(f"Writing {name} to {path}")
        df.write.mode("overwrite").parquet(path)

    def run(self):
        telemetry = self.read_telemetry()
        flights = self.read_flight_records()
        maintenance = self.read_maintenance_logs()

        self.write(telemetry, "validated_telemetry")
        self.write(flights, "validated_flights")
        self.write(maintenance, "validated_maintenance")

        logger.info("Ingestion job complete.")
        return {"telemetry": telemetry.count(), "flights": flights.count(), "maintenance": maintenance.count()}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Processing date YYYY-MM-DD")
    parser.add_argument("--s3-bucket", default="aa-ml-data-lake")
    parser.add_argument("--output-path", default="s3://aa-ml-data-lake/processed")
    args = parser.parse_args()

    spark = (
        SparkSession.builder
        .appName(f"TelemetryIngestion-{args.date}")
        .config("spark.sql.session.timeZone", "UTC")
        .getOrCreate()
    )

    job = TelemetryIngestionJob(spark, args.date, args.s3_bucket, args.output_path)
    counts = job.run()
    logger.info(f"Record counts: {counts}")
    spark.stop()


if __name__ == "__main__":
    main()
