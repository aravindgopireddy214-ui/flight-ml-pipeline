"""
late_arrival_handler.py
-----------------------
Detects and handles late-arriving records in telemetry streams.

Aviation telemetry can arrive hours or even days late due to:
  - Intermittent satellite uplink connectivity on long-haul routes
  - Ground system buffering during high-traffic periods
  - Fleet-generation differences in onboard data recorders

Strategy:
  1. Flag records whose event_ts falls outside the expected processing window
  2. Route late records into a backfill queue keyed by (tail_number, date)
  3. Trigger downstream feature recomputation for affected feature windows
"""

import logging
from datetime import datetime, timedelta

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import BooleanType

logger = logging.getLogger(__name__)


class LateArrivalHandler:
    """
    Flags records that arrived outside the nominal processing window.

    Parameters
    ----------
    lookback_days : int
        How many calendar days back to consider a record "late but acceptable"
        vs. "too stale to use". Records older than this are dropped.
    """

    def __init__(self, lookback_days: int = 3):
        self.lookback_days = lookback_days

    def detect_and_flag(self, df: DataFrame, ts_col: str = "event_ts") -> DataFrame:
        """
        Adds two columns:
          _is_late        : True if record arrived outside the nominal window
          _backfill_date  : The calendar date the record *should* have been processed
        Drops records older than lookback_days.
        """
        now = F.current_timestamp()
        cutoff = F.date_sub(F.current_date(), self.lookback_days)

        df = df.withColumn(
            "_is_late",
            F.col(ts_col).cast("date") < F.current_date()
        ).withColumn(
            "_backfill_date",
            F.when(F.col("_is_late"), F.col(ts_col).cast("date")).otherwise(F.lit(None))
        )

        # Drop records too stale to be useful
        before = df.count()
        df = df.filter(F.col(ts_col).cast("date") >= cutoff)
        after = df.count()
        dropped = before - after

        if dropped > 0:
            logger.warning(
                f"Dropped {dropped} records older than {self.lookback_days} days "
                f"(cutoff: {cutoff}). These are too stale for feature windows."
            )

        late_count = df.filter(F.col("_is_late")).count()
        if late_count > 0:
            logger.info(
                f"Flagged {late_count} late-arriving records for backfill processing."
            )
            self._register_backfill_tasks(df.filter(F.col("_is_late")))

        return df

    def _register_backfill_tasks(self, late_df: DataFrame):
        """
        Collects distinct (tail_number, backfill_date) pairs and logs them
        as backfill tasks. In production this would write to a task queue
        (e.g. SQS or an Airflow trigger) to recompute affected feature windows.
        """
        tasks = (
            late_df
            .select("tail_number", "_backfill_date")
            .distinct()
            .collect()
        )
        for row in tasks:
            logger.info(
                f"Backfill required: tail={row['tail_number']} "
                f"date={row['_backfill_date']}"
            )
        # TODO: publish to SQS backfill queue for Airflow DAG trigger
