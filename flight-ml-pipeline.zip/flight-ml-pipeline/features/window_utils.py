"""
window_utils.py
---------------
Helpers for constructing point-in-time safe Spark window specifications.

The golden rule for time-series ML: a feature for event at time T
must only use data available strictly before T (or before T - some
prediction horizon offset). Violating this causes target leakage —
models appear to work in training but fail silently in production.
"""

from pyspark.sql.window import Window
from pyspark.sql import functions as F


def safe_rolling_window(partition_col: str, ts_col: str, days: int) -> Window:
    """
    Returns a Window spec that looks back `days` calendar days from
    the current row's timestamp, exclusive of the current row.

    Uses range-based (time-based) rather than row-based framing
    so the window is consistently defined regardless of data density.

    Parameters
    ----------
    partition_col : str
        Column to partition by (e.g. "tail_number", "route")
    ts_col : str
        Timestamp column (must be castable to long/seconds for range frame)
    days : int
        Lookback window in calendar days
    """
    seconds = days * 86400
    return (
        Window
        .partitionBy(partition_col)
        .orderBy(F.col(ts_col).cast("long"))
        .rangeBetween(-seconds, -1)   # -1 excludes current row (point-in-time safe)
    )


def unbounded_trailing_window(partition_col: str, ts_col: str) -> Window:
    """
    All rows up to but not including the current row.
    Useful for cumulative statistics (e.g. lifetime delay count).
    """
    return (
        Window
        .partitionBy(partition_col)
        .orderBy(F.col(ts_col).cast("long"))
        .rowsBetween(Window.unboundedPreceding, -1)
    )
