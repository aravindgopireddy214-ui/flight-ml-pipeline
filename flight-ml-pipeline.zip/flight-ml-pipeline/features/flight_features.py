"""
flight_features.py
------------------
Feature engineering for the flight delay prediction model.

All features are computed with strict point-in-time correctness:
only data available at prediction time (scheduled_dep - 2hr) is used.
This prevents target leakage, which is the most common silent failure
mode in time-series ML pipelines.
"""

import argparse
import logging
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from window_utils import safe_rolling_window

logger = logging.getLogger(__name__)


class FlightDelayFeatures:
    """
    Builds the feature matrix for delay prediction.
    Prediction horizon: 2 hours before scheduled departure.
    """

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def build(self, flights: DataFrame, telemetry: DataFrame, maintenance: DataFrame) -> DataFrame:
        df = flights
        df = self._add_schedule_features(df)
        df = self._add_aircraft_history_features(df, flights)
        df = self._add_telemetry_features(df, telemetry)
        df = self._add_maintenance_features(df, maintenance)
        df = self._add_label(df)
        return df

    def _add_schedule_features(self, df: DataFrame) -> DataFrame:
        """Time-of-day, day-of-week, and route-based features."""
        return (
            df
            .withColumn("dep_hour", F.hour("scheduled_dep"))
            .withColumn("dep_dow", F.dayofweek("scheduled_dep"))
            .withColumn("dep_month", F.month("scheduled_dep"))
            .withColumn("is_weekend", (F.col("dep_dow").isin([1, 7])).cast("int"))
            .withColumn("route", F.concat_ws("-", "origin", "destination"))
        )

    def _add_aircraft_history_features(self, df: DataFrame, all_flights: DataFrame) -> DataFrame:
        """
        Rolling delay statistics per tail number over prior 7 and 30 days.
        Uses point-in-time safe window: only flights that departed before
        (scheduled_dep - 2hr) for each record.
        """
        history = (
            all_flights
            .select("tail_number", "scheduled_dep", "delay_minutes")
            .withColumnRenamed("scheduled_dep", "hist_dep")
            .withColumnRenamed("delay_minutes", "hist_delay")
        )

        df = df.join(history, on="tail_number", how="left")
        # Only use history strictly before prediction cutoff (scheduled_dep - 2hr)
        df = df.filter(
            F.col("hist_dep") < (F.col("scheduled_dep") - F.expr("INTERVAL 2 HOURS"))
        )

        tail_window_7d = safe_rolling_window("tail_number", "scheduled_dep", days=7)
        tail_window_30d = safe_rolling_window("tail_number", "scheduled_dep", days=30)

        df = (
            df
            .withColumn("tail_avg_delay_7d", F.avg("hist_delay").over(tail_window_7d))
            .withColumn("tail_avg_delay_30d", F.avg("hist_delay").over(tail_window_30d))
            .withColumn("tail_delay_count_7d", F.count("hist_delay").over(tail_window_7d))
            .drop("hist_dep", "hist_delay")
            .dropDuplicates(["flight_id"])
        )
        return df

    def _add_telemetry_features(self, df: DataFrame, telemetry: DataFrame) -> DataFrame:
        """
        Aggregate telemetry stats for the aircraft in the 6 hours before departure.
        Proxy for mechanical health at departure time.
        """
        telem_agg = (
            telemetry
            .groupBy("tail_number", F.col("event_ts").cast("date").alias("telem_date"))
            .agg(
                F.avg("engine_temp_c").alias("avg_engine_temp"),
                F.max("vibration_hz").alias("max_vibration"),
                F.avg("fuel_flow_kg_hr").alias("avg_fuel_flow"),
                F.stddev("engine_temp_c").alias("std_engine_temp"),
            )
        )
        df = df.withColumn("dep_date", F.col("scheduled_dep").cast("date"))
        df = df.join(telem_agg, on=["tail_number", F.col("dep_date") == F.col("telem_date")], how="left")
        return df.drop("telem_date", "dep_date")

    def _add_maintenance_features(self, df: DataFrame, maintenance: DataFrame) -> DataFrame:
        """Days since last maintenance event per tail number."""
        last_maint = (
            maintenance
            .groupBy("tail_number")
            .agg(F.max("event_ts").alias("last_maintenance_ts"))
        )
        df = df.join(last_maint, on="tail_number", how="left")
        df = df.withColumn(
            "days_since_maintenance",
            F.datediff(F.col("scheduled_dep"), F.col("last_maintenance_ts"))
        )
        return df.drop("last_maintenance_ts")

    def _add_label(self, df: DataFrame) -> DataFrame:
        """Binary label: 1 if delay >= 15 minutes."""
        return df.withColumn(
            "label_delay",
            (F.col("delay_minutes") >= 15).cast("int")
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True)
    parser.add_argument("--input-path", default="s3://aa-ml-data-lake/processed")
    parser.add_argument("--output-path", default="s3://aa-ml-data-lake/features")
    args = parser.parse_args()

    spark = SparkSession.builder.appName(f"FlightFeatures-{args.date}").getOrCreate()

    flights = spark.read.parquet(f"{args.input_path}/validated_flights/date={args.date}")
    telemetry = spark.read.parquet(f"{args.input_path}/validated_telemetry/date={args.date}")
    maintenance = spark.read.parquet(f"{args.input_path}/validated_maintenance/date={args.date}")

    builder = FlightDelayFeatures(spark)
    features = builder.build(flights, telemetry, maintenance)

    out = f"{args.output_path}/flight_delay/date={args.date}"
    features.write.mode("overwrite").parquet(out)
    logger.info(f"Wrote {features.count()} feature rows to {out}")
    spark.stop()


if __name__ == "__main__":
    main()
