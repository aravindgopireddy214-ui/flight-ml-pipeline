"""
monitor.py
----------
Production drift detection and alerting for deployed ML endpoints.

Monitors:
  - Feature distribution drift (PSI — Population Stability Index)
  - Prediction distribution drift
  - Model performance degradation (where labels are available)

Triggers retraining workflow when thresholds are breached.
"""

import logging
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import boto3

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

PSI_THRESHOLD = 0.2        # > 0.2 = significant shift, trigger alert
PERF_DROP_THRESHOLD = 0.05 # AUC drop > 5pp triggers retraining alert
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:123456789012:ml-drift-alerts"


@dataclass
class DriftReport:
    feature_psi: Dict[str, float] = field(default_factory=dict)
    prediction_psi: float = 0.0
    auc_current: Optional[float] = None
    auc_baseline: Optional[float] = None
    alerts: List[str] = field(default_factory=list)

    @property
    def has_alerts(self) -> bool:
        return len(self.alerts) > 0


def compute_psi(baseline: np.ndarray, current: np.ndarray, buckets: int = 10) -> float:
    """
    Population Stability Index measures distribution shift between
    a baseline (training) and current (production) distribution.

    PSI < 0.1  : no significant change
    PSI 0.1–0.2: moderate change, monitor closely
    PSI > 0.2  : significant change, investigate / retrain
    """
    baseline = baseline[~np.isnan(baseline)]
    current = current[~np.isnan(current)]

    breakpoints = np.percentile(baseline, np.linspace(0, 100, buckets + 1))
    breakpoints[0] = -np.inf
    breakpoints[-1] = np.inf

    baseline_counts = np.histogram(baseline, bins=breakpoints)[0]
    current_counts = np.histogram(current, bins=breakpoints)[0]

    # Avoid division by zero / log(0)
    baseline_pct = np.clip(baseline_counts / len(baseline), 1e-6, None)
    current_pct = np.clip(current_counts / len(current), 1e-6, None)

    psi = np.sum((current_pct - baseline_pct) * np.log(current_pct / baseline_pct))
    return float(psi)


class DriftMonitor:

    def __init__(self, baseline_stats_path: str):
        with open(baseline_stats_path) as f:
            self.baseline_stats = json.load(f)

    def run(self, current_df: pd.DataFrame, current_predictions: np.ndarray,
            current_labels: Optional[np.ndarray] = None) -> DriftReport:
        report = DriftReport()

        # Feature drift
        for col, baseline_vals in self.baseline_stats.get("features", {}).items():
            if col not in current_df.columns:
                continue
            psi = compute_psi(np.array(baseline_vals), current_df[col].values)
            report.feature_psi[col] = psi
            if psi > PSI_THRESHOLD:
                msg = f"Feature drift alert: {col} PSI={psi:.3f} (threshold={PSI_THRESHOLD})"
                logger.warning(msg)
                report.alerts.append(msg)

        # Prediction drift
        baseline_preds = np.array(self.baseline_stats.get("predictions", []))
        if len(baseline_preds) > 0:
            report.prediction_psi = compute_psi(baseline_preds, current_predictions)
            if report.prediction_psi > PSI_THRESHOLD:
                msg = f"Prediction drift alert: PSI={report.prediction_psi:.3f}"
                logger.warning(msg)
                report.alerts.append(msg)

        # Performance degradation (when ground truth labels arrive)
        if current_labels is not None:
            from sklearn.metrics import roc_auc_score
            report.auc_current = roc_auc_score(current_labels, current_predictions)
            report.auc_baseline = self.baseline_stats.get("auc_baseline")
            if report.auc_baseline and (report.auc_baseline - report.auc_current) > PERF_DROP_THRESHOLD:
                msg = (f"Performance degradation alert: AUC dropped from "
                       f"{report.auc_baseline:.4f} to {report.auc_current:.4f}")
                logger.warning(msg)
                report.alerts.append(msg)

        if report.has_alerts:
            self._publish_alerts(report)

        return report

    def _publish_alerts(self, report: DriftReport):
        """Publish alerts to SNS for PagerDuty / Slack routing."""
        try:
            sns = boto3.client("sns", region_name="us-east-1")
            message = "\n".join(report.alerts)
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject="[ML Drift Alert] Flight Delay Model",
                Message=message,
            )
            logger.info(f"Published {len(report.alerts)} alerts to SNS.")
        except Exception as e:
            logger.error(f"Failed to publish SNS alerts: {e}")
