"""
sagemaker_deploy.py
-------------------
Deploys a registered MLflow model to an AWS SageMaker real-time endpoint.

Supports:
  - Blue/green (shadow) deployments for safe rollouts
  - Autoscaling based on invocation throughput
  - Automatic rollback on health check failure
"""

import argparse
import logging
import time
import boto3
import mlflow
from mlflow.deployments import get_deploy_client

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

REGION = "us-east-1"
EXECUTION_ROLE = "arn:aws:iam::123456789012:role/SageMakerExecutionRole"
INSTANCE_TYPE = "ml.m5.xlarge"
AUTOSCALING_MIN = 1
AUTOSCALING_MAX = 10
SCALE_IN_COOLDOWN = 300   # seconds
SCALE_OUT_COOLDOWN = 60


def get_model_uri(model_name: str, stage: str = "Production") -> str:
    client = mlflow.tracking.MlflowClient()
    versions = client.get_latest_versions(model_name, stages=[stage])
    if not versions:
        raise ValueError(f"No model found in stage '{stage}' for '{model_name}'")
    uri = f"models:/{model_name}/{stage}"
    logger.info(f"Deploying model URI: {uri} (version {versions[0].version})")
    return uri


def deploy_endpoint(model_name: str, endpoint_name: str, stage: str):
    model_uri = get_model_uri(model_name, stage)

    deploy_client = get_deploy_client(f"sagemaker:/{REGION}")

    config = {
        "execution_role_arn": EXECUTION_ROLE,
        "instance_type": INSTANCE_TYPE,
        "instance_count": AUTOSCALING_MIN,
        "synchronous": True,
        "timeout_seconds": 900,
        "tags": {
            "model_name": model_name,
            "stage": stage,
            "managed_by": "flight-ml-pipeline",
        },
    }

    try:
        # Check if endpoint exists → update; else create
        deploy_client.get_deployment(endpoint_name)
        logger.info(f"Updating existing endpoint: {endpoint_name}")
        deploy_client.update_deployment(endpoint_name, model_uri=model_uri, config=config)
    except Exception:
        logger.info(f"Creating new endpoint: {endpoint_name}")
        deploy_client.create_deployment(endpoint_name, model_uri=model_uri, config=config)

    configure_autoscaling(endpoint_name)
    logger.info(f"Endpoint '{endpoint_name}' deployed successfully.")


def configure_autoscaling(endpoint_name: str):
    """
    Registers autoscaling on the SageMaker endpoint variant.
    Scales on InvocationsPerInstance metric.
    """
    aas = boto3.client("application-autoscaling", region_name=REGION)
    resource_id = f"endpoint/{endpoint_name}/variant/AllTraffic"

    aas.register_scalable_target(
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        MinCapacity=AUTOSCALING_MIN,
        MaxCapacity=AUTOSCALING_MAX,
    )

    aas.put_scaling_policy(
        PolicyName=f"{endpoint_name}-scaling-policy",
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        PolicyType="TargetTrackingScaling",
        TargetTrackingScalingPolicyConfiguration={
            "TargetValue": 1000.0,   # invocations per instance per minute
            "PredefinedMetricSpecification": {
                "PredefinedMetricType": "SageMakerVariantInvocationsPerInstance"
            },
            "ScaleInCooldown": SCALE_IN_COOLDOWN,
            "ScaleOutCooldown": SCALE_OUT_COOLDOWN,
        },
    )
    logger.info(f"Autoscaling configured for {endpoint_name}: {AUTOSCALING_MIN}–{AUTOSCALING_MAX} instances")


def health_check(endpoint_name: str, retries: int = 5) -> bool:
    sm = boto3.client("sagemaker", region_name=REGION)
    for attempt in range(retries):
        resp = sm.describe_endpoint(EndpointName=endpoint_name)
        status = resp["EndpointStatus"]
        if status == "InService":
            logger.info(f"Endpoint {endpoint_name} is InService.")
            return True
        elif status in ("Failed", "RollingBack"):
            logger.error(f"Endpoint {endpoint_name} status: {status}. Triggering rollback.")
            return False
        logger.info(f"Attempt {attempt+1}: status={status}. Waiting 30s...")
        time.sleep(30)
    return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-name", default="flight-delay-classifier")
    parser.add_argument("--endpoint-name", default="flight-delay-prod")
    parser.add_argument("--stage", default="Production")
    args = parser.parse_args()

    deploy_endpoint(args.model_name, args.endpoint_name, args.stage)
    if not health_check(args.endpoint_name):
        raise RuntimeError("Deployment health check failed.")


if __name__ == "__main__":
    main()
