"""
delay_classifier.py
-------------------
Training pipeline for the flight delay classification model.

Uses XGBoost / LightGBM with cross-validation, threshold tuning,
and MLflow experiment tracking. Promotes best model to registry staging.
"""

import argparse
import logging
import json
from typing import Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb
import mlflow
import mlflow.xgboost

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

FEATURE_COLS = [
    "dep_hour", "dep_dow", "dep_month", "is_weekend",
    "tail_avg_delay_7d", "tail_avg_delay_30d", "tail_delay_count_7d",
    "avg_engine_temp", "max_vibration", "avg_fuel_flow", "std_engine_temp",
    "days_since_maintenance",
]
LABEL_COL = "label_delay"
CATEGORICAL_COLS = ["route", "origin", "destination", "aircraft_type"]

XGB_PARAMS = {
    "n_estimators": 500,
    "max_depth": 6,
    "learning_rate": 0.05,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "scale_pos_weight": 3,   # class imbalance adjustment
    "eval_metric": "auc",
    "early_stopping_rounds": 30,
    "random_state": 42,
}


def load_features(features_path: str) -> pd.DataFrame:
    import pyarrow.parquet as pq
    return pq.read_table(features_path).to_pandas()


def encode_categoricals(df: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    encoders = {}
    for col in CATEGORICAL_COLS:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].fillna("UNKNOWN").astype(str))
            encoders[col] = le
    return df, encoders


def tune_threshold(y_true: np.ndarray, y_prob: np.ndarray, beta: float = 1.0) -> float:
    """
    Find threshold maximizing F-beta score on validation fold.
    beta=1 balances precision/recall; beta<1 favors precision.
    """
    best_thresh, best_score = 0.5, 0.0
    for t in np.arange(0.1, 0.9, 0.02):
        y_pred = (y_prob >= t).astype(int)
        p = precision_score(y_true, y_pred, zero_division=0)
        r = recall_score(y_true, y_pred, zero_division=0)
        if p + r == 0:
            continue
        fb = (1 + beta**2) * p * r / (beta**2 * p + r)
        if fb > best_score:
            best_score, best_thresh = fb, t
    return best_thresh


def train(features_path: str, experiment_name: str, model_name: str):
    mlflow.set_experiment(experiment_name)

    df = load_features(features_path)
    df, encoders = encode_categoricals(df)

    all_feature_cols = FEATURE_COLS + [c for c in CATEGORICAL_COLS if c in df.columns]
    X = df[all_feature_cols].fillna(-999)
    y = df[LABEL_COL]

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    oof_probs = np.zeros(len(y))

    fold_metrics = []

    with mlflow.start_run(run_name=f"delay_xgb_cv"):
        mlflow.log_params(XGB_PARAMS)
        mlflow.log_param("n_features", len(all_feature_cols))
        mlflow.log_param("n_samples", len(df))
        mlflow.log_param("positive_rate", float(y.mean()))

        for fold, (train_idx, val_idx) in enumerate(cv.split(X, y)):
            X_tr, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_tr, y_val = y.iloc[train_idx], y.iloc[val_idx]

            model = xgb.XGBClassifier(**XGB_PARAMS)
            model.fit(
                X_tr, y_tr,
                eval_set=[(X_val, y_val)],
                verbose=False
            )
            val_probs = model.predict_proba(X_val)[:, 1]
            oof_probs[val_idx] = val_probs

            thresh = tune_threshold(y_val.values, val_probs)
            y_pred = (val_probs >= thresh).astype(int)

            metrics = {
                "fold": fold,
                "auc": roc_auc_score(y_val, val_probs),
                "precision": precision_score(y_val, y_pred),
                "recall": recall_score(y_val, y_pred),
                "f1": f1_score(y_val, y_pred),
                "threshold": thresh,
            }
            fold_metrics.append(metrics)
            logger.info(f"Fold {fold}: {metrics}")

        # Aggregate OOF metrics
        oof_thresh = tune_threshold(y.values, oof_probs)
        oof_pred = (oof_probs >= oof_thresh).astype(int)
        mlflow.log_metrics({
            "oof_auc": roc_auc_score(y, oof_probs),
            "oof_precision": precision_score(y, oof_pred),
            "oof_recall": recall_score(y, oof_pred),
            "oof_f1": f1_score(y, oof_pred),
            "oof_threshold": oof_thresh,
        })

        # Retrain on full data
        final_model = xgb.XGBClassifier(**XGB_PARAMS)
        final_model.fit(X, y, verbose=False)
        mlflow.xgboost.log_model(final_model, "model", registered_model_name=model_name)

        # Log feature importances
        importances = dict(zip(all_feature_cols, final_model.feature_importances_))
        mlflow.log_dict(importances, "feature_importances.json")

        logger.info(f"Training complete. OOF AUC: {roc_auc_score(y, oof_probs):.4f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--features-path", required=True)
    parser.add_argument("--experiment-name", default="flight-delay-prediction")
    parser.add_argument("--model-name", default="flight-delay-classifier")
    args = parser.parse_args()
    train(args.features_path, args.experiment_name, args.model_name)


if __name__ == "__main__":
    main()
