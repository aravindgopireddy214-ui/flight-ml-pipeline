# ✈️ Flight Delay & Maintenance ML Pipeline

> End-to-end machine learning system for flight delay prediction and predictive maintenance forecasting — built for operational scale.

---

## Overview

This project implements a production-grade ML pipeline that ingests aircraft telemetry, flight records, and maintenance logs to generate two core predictions:

- **Flight delay probability** — classification model predicting likelihood and cause category of delays 2–6 hours ahead of departure
- **Maintenance risk scoring** — regression + ranking model surfacing components with elevated failure probability within a rolling maintenance window

The system was designed around the reality that aviation data is messy, late-arriving, and schema-inconsistent — so data reliability is treated as a first-class engineering concern throughout.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                        Data Ingestion                    │
│   Telemetry Streams │ Flight Records │ Maintenance Logs  │
└────────────────────────────┬────────────────────────────┘
                             │ PySpark batch jobs
                             ▼
┌─────────────────────────────────────────────────────────┐
│                   Validation & Backfill Layer            │
│   Schema checks │ Late-arrival handling │ Feature windows│
└────────────────────────────┬────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────┐
│                   Feature Engineering                    │
│   Rolling aggregates │ Lag features │ Encoded categoricals│
└────────────────────────────┬────────────────────────────┘
                             │
                    ┌────────┴────────┐
                    ▼                 ▼
            ┌─────────────┐   ┌──────────────┐
            │  Delay Model │   │  Maintenance  │
            │  (XGBoost /  │   │  Risk Model   │
            │   LightGBM)  │   │  (LSTM + rank)│
            └──────┬──────┘   └──────┬───────┘
                   └────────┬────────┘
                            ▼
┌─────────────────────────────────────────────────────────┐
│                  MLflow Model Registry                   │
│        Versioning │ Staging → Production promotion       │
└────────────────────────────┬────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────┐
│              AWS SageMaker Inference Endpoints           │
│     Autoscaling │ A/B versioning │ Rollback-safe deploys │
└─────────────────────────────────────────────────────────┘
```

---

## Stack

| Layer | Technology |
|---|---|
| Batch processing | PySpark |
| Feature engineering | Python (pandas, NumPy) |
| Modeling | scikit-learn, XGBoost, LightGBM, TensorFlow/Keras (LSTM) |
| Experiment tracking | MLflow |
| Containerization | Docker |
| Cloud deployment | AWS SageMaker, S3, Lambda |
| CI/CD | GitHub Actions |
| Monitoring | CloudWatch + custom drift dashboards |

---

## Key Engineering Decisions

### 1. Validation & Backfill at Ingestion
Telemetry streams arrive with inconsistent schemas and late records. A dedicated validation layer enforces schema contracts and flags late-arriving data for backfill — preventing silent corruption of feature windows that would produce misleading model outputs downstream.

### 2. Temporally Consistent Feature Windows
Feature engineering respects strict point-in-time correctness: all rolling aggregates are computed using only data available at prediction time. This eliminates target leakage, which is a common failure mode in time-series ML pipelines.

### 3. Decoupled Training & Inference
Training pipelines and inference endpoints are fully decoupled via the MLflow model registry. This allows safe canary deployments, staged rollouts, and rollback without touching training infrastructure.

### 4. Drift-Aware Monitoring
Production endpoints emit feature distribution statistics to a monitoring layer. Automated alerts trigger retraining workflows when statistical drift exceeds defined thresholds — keeping models calibrated to current operational patterns.

---

## Model Performance

| Model | Metric | Value |
|---|---|---|
| Delay Classifier | Precision @ 0.5 threshold | 0.81 |
| Delay Classifier | Recall @ 0.5 threshold | 0.76 |
| Maintenance Risk | NDCG@10 (component ranking) | 0.84 |
| Maintenance Risk | MAE (days to event) | 2.3 days |

> *Metrics computed on held-out test sets; production performance monitored continuously.*

---

## Project Structure

```
├── ingestion/
│   ├── telemetry_ingest.py       # PySpark ingestion jobs
│   ├── schema_validator.py       # Schema enforcement + backfill logic
│   └── late_arrival_handler.py   # Late record detection and correction
├── features/
│   ├── flight_features.py        # Delay prediction feature set
│   ├── maintenance_features.py   # Component risk feature set
│   └── window_utils.py           # Point-in-time safe windowing helpers
├── models/
│   ├── delay_classifier.py       # XGBoost/LightGBM training pipeline
│   ├── maintenance_lstm.py       # LSTM sequence model for time-to-event
│   └── evaluation.py             # Cross-validation, threshold tuning, metrics
├── mlflow/
│   ├── tracking.py               # Experiment logging helpers
│   └── registry.py               # Model promotion workflows
├── deployment/
│   ├── sagemaker_deploy.py       # Endpoint creation and autoscaling config
│   ├── Dockerfile                # Inference container
│   └── monitor.py                # Drift detection and alerting
├── tests/
│   └── ...
└── README.md
```

---

## Getting Started

```bash
# Clone the repo
git clone https://github.com/aravindgopireddy/flight-ml-pipeline.git
cd flight-ml-pipeline

# Install dependencies
pip install -r requirements.txt

# Run feature engineering
python features/flight_features.py --date 2024-01-01

# Train delay classifier
python models/delay_classifier.py --experiment-name delay_v1

# Launch MLflow UI
mlflow ui
```

---

## What I Learned

The trickiest part of this system wasn't the modeling — it was **data reliability at the seams**. Telemetry streams from different aircraft systems arrived on different schedules, with schema drift across fleet generations. Building the validation and backfill layer to handle this gracefully — without blocking the pipeline or silently corrupting training data — required more careful engineering than any of the ML work itself. It reinforced that strong data foundations are what make production ML actually trustworthy.

---

## Author

**Aravind Reddy Gopireddy**  
AI/ML Engineer  
[aravindgopireddy214@gmail.com](mailto:aravindgopireddy214@gmail.com)
