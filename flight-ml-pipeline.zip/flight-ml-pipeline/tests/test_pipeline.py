"""
tests/test_schema_validator.py
"""
import pytest
from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("test")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )


def test_psi_no_drift():
    """PSI should be ~0 when distributions are identical."""
    import numpy as np
    from deployment.monitor import compute_psi
    baseline = np.random.normal(0, 1, 1000)
    psi = compute_psi(baseline, baseline.copy())
    assert psi < 0.05


def test_psi_high_drift():
    """PSI should be high when distributions are very different."""
    import numpy as np
    from deployment.monitor import compute_psi
    baseline = np.random.normal(0, 1, 1000)
    shifted = np.random.normal(5, 1, 1000)
    psi = compute_psi(baseline, shifted)
    assert psi > 0.2


def test_window_utils_rolling(spark):
    """Rolling window should not include current row (point-in-time safe)."""
    from pyspark.sql import functions as F
    from features.window_utils import safe_rolling_window

    data = [("T1", 1000, 10.0), ("T1", 2000, 20.0), ("T1", 3000, 30.0)]
    df = spark.createDataFrame(data, ["tail", "ts", "val"])
    w = safe_rolling_window("tail", "ts", days=1)
    df2 = df.withColumn("rolling_avg", F.avg("val").over(w))
    rows = {r["ts"]: r["rolling_avg"] for r in df2.collect()}
    # First row has no prior data
    assert rows[1000] is None
